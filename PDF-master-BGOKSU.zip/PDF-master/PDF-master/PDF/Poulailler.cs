﻿using System;
using System.Collections.Generic;

namespace PDF
{
    public class Poulailler
    {
        private string nom;
        private int capaMax;
        private List<Poule> poules;

        public Poulailler(string nomP, int capaMaxP)
        {
            nom = nomP;
            capaMax = capaMaxP;
            poules = new List<Poule>();
        }

        public void AjouterPoule(Poule poule)
        {
            if (poules.Count < capaMax)
            {
                poules.Add(poule);
                Console.WriteLine("La poule a bien été ajoutée");
            }
            else
            {
                Console.WriteLine("Le poulailler est rempli, il est impossible d'ajouter une nouvelle poule");
            }
        }

        public void AfficherPoules()
        {
            Console.WriteLine($"Poules à l'intérieur du poulailler '{nom}':");

            if (poules.Count == 0)
            {
                Console.WriteLine("Le poulailler est vide");
            }
            else
            {
                for (int i = 0; i < poules.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {poules[i].Nom} ({poules[i].Race})");
                }

                Console.WriteLine($"Total: {poules.Count} poules");
            }
        }

        public void SupprimerPoule(int numeroAffichage)
        {
            int index = numeroAffichage - 1;

            if (index >= 0 && index < poules.Count)
            {
                poules.RemoveAt(index);
                Console.WriteLine("La poule a bien été supprimée");
            }
            else
            {
                Console.WriteLine("Numéro d'affichage incorrect, il est impossible de supprimer la poule");
            }
        }
        public void RenommerPoule(int numeroAffichage, string nouveauNom)
        {
            if (numeroAffichage > 0 && numeroAffichage <= poules.Count)
            {
                Poule poule = poules[numeroAffichage - 1];
                poule = new Poule(nouveauNom, poule.Race, poule.IntensitePonte, poule.Taille);
                poules[numeroAffichage - 1] = poule;
                Console.WriteLine("La poule a été renommée avec succès.");
            }
            else
            {
                Console.WriteLine("Numéro d'affichage incorrect, impossible de renommer la poule.");
            }
        }


    }
}
