﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PDF
{
    public class Poule
    {
        public string Nom { get; }
        public string Race { get; }
        public double IntensitePonte { get; }
        public Taille Taille { get; }

        public Poule(string nom, string race, double intensitePonte, Taille taille)
        {
            Nom = nom;
            Race = race;
            IntensitePonte = intensitePonte;
            Taille = taille;
        }

        public void Afficher()
        {
            Console.WriteLine($"{Nom} ({Race})");
        }
    }
}
