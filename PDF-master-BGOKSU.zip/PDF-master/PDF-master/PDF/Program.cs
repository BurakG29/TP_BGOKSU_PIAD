﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PDF;

namespace PDFConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Poulailler poulailler = new Poulailler("Mon premier poulailler", 10);

            Poule Coco = new Poule("Coco", "Plymouth Rock", 0.8, Taille.L);
            poulailler.AjouterPoule(Coco);

            Poule Betsy = new Poule("Betsy", "Marans", 0.7, Taille.M);
            poulailler.AjouterPoule(Betsy);

            Poule Daisy = new Poule("Daisy", "Brahma", 0.9, Taille.M);
            poulailler.AjouterPoule(Daisy);

            poulailler.AfficherPoules();

            poulailler.SupprimerPoule(2);

            poulailler.AfficherPoules();

            Poulailler poulailler2 = new Poulailler("Mon deuxième poulailler", 5);

            Poule Cocorico = new Poule("Cocorico", "Plymouth Rock", 0.6, Taille.S);
            poulailler2.AjouterPoule(Cocorico);

            Poule Betty = new Poule("Betty", "Wyandotte", 0.7, Taille.M);
            poulailler2.AjouterPoule(Betty);

            Poule Amelia = new Poule("Amelia", "Brahma", 0.8, Taille.L);
            poulailler2.AjouterPoule(Amelia);

            Poule Penny = new Poule("Penny", "Orpington", 0.9, Taille.XL);
            poulailler2.AjouterPoule(Penny);

            Poule Sophie = new Poule("Sophie", "Silkie", 0.7, Taille.M);
            poulailler2.AjouterPoule(Sophie);

            poulailler2.AfficherPoules();

            poulailler2.SupprimerPoule(3);

            poulailler2.AfficherPoules();

            poulailler2.RenommerPoule(4, "Anne");

            poulailler2.AfficherPoules();
        }
    }
}

